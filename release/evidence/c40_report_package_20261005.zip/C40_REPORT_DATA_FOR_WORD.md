# BÁO CÁO DỮ LIỆU ĐÃ XÁC NHẬN — STAGE 2 H3, MỤC TIÊU 40 ns

Ngày tổng hợp: 2026-10-05

> Tài liệu này tổng hợp trực tiếp từ archive đã có. Không chạy lại mô phỏng hoặc OpenLane khi xuất báo cáo.

## 1. Kết luận có thể dùng trong báo cáo

- RUN vật lý: `s2_h3_c40_monolithic_06`.
- Trạng thái chính thức: `C40_MONOLITHIC_79_CLASSIC_PASS_WITH_DOCUMENTED_GUIDANCE`.
- Mục tiêu clock: **40 ns = 25 MHz**.
- OpenLane Classic: **79/79 stage cấu hình hoàn tất**, exit code `0`; có 76 thư mục stage thực tế vì bước bị vô hiệu hóa/gating không tạo thư mục riêng.
- STA hậu RCX: setup xấu nhất **+7.542642 ns** tại `max_ss_100C_1v60`; hold xấu nhất **+0.116533 ns** tại `max_ff_n40C_1v95`; **0 setup/hold violation ở cả 9 corner**.
- Slew/capacitance/fanout: **0/0/0 ở cả 9 corner**.
- Routing DRC, disconnected pins, antenna, Magic DRC, KLayout DRC, XOR, illegal overlap và LVS đều có metric cuối bằng **0**.
- Tổng công suất ước lượng: **14.942068 mW**; đây là power vectorless/default activity, không phải công suất workload đo trên silicon.

## 2. Phạm vi phần cứng được đo

Physical top là `picorv32_h3_logic_ppa`: PicoRV32 + H3 image-processing logic, controller và giao tiếp bus nằm trong top tổng hợp. External program/image RAM, UART, pads/package và camera không nằm trong diện tích/công suất của top này. Functional simulation là bằng chứng riêng.

Công nghệ: OpenLane Classic 2.3.10, `sky130A`, standard-cell library `sky130_fd_sc_hd`; PDK revision `0fe599b2afb6708d281543108caf8310912f54af`; Docker image `sha256:37c3bd4ea0534a276cb2deb88d601044857bad2807b9bc5b36efe9d02c62624e`.

## 3. PPA

| Chỉ tiêu | Giá trị |
|---|---:|
| Clock period / frequency | 40 ns / 25 MHz |
| Die | 0.0 0.0 1079.4 1090.12 µm |
| Core | 5.52 10.88 1073.64 1077.12 µm |
| Die area | 1176680 µm² = 1.176680 mm² |
| Core area | 1138870 µm² = 1.138870 mm² |
| Standard-cell instance area | 477911 µm² = 0.477911 mm² |
| Utilization | 41.9635% |
| Instance count | 64421 |
| IO / hard macros | 108 / 0 |
| Internal power | 10.107018 mW |
| Switching power | 4.834442 mW |
| Leakage power | 0.607611 µW |
| Total power | 14.942068 mW |

Cell/routing details: 4563 sequential cells; 29250 multi-input combinational cells; 6819 timing-repair buffers; 1670 clock buffers; 101 hold buffers; 4487 antenna cells (1005 diodes); 43466 routed signal nets; 2,675,321 µm routed wire; 407,777 vias; longest wire 1121.95 µm.

## 4. STA chín corner và kiểm tra môi trường cực đoan

`min/nom/max` là các bộ RC/parasitic; `ss/tt/ff` là process corner; nhiệt độ và điện áp nằm trong tên corner. Hai biên PVT quan trọng là slow/hot/low-voltage `ss, 100°C, 1.60 V` và fast/cold/high-voltage `ff, −40°C, 1.95 V`.

| Corner | Setup slack (ns) | Hold slack (ns) | Setup/Hold vio | Slew/Cap/Fanout |
|---|---:|---:|---:|---:|
| `min_ss_100C_1v60` | 10.523479 | 0.700241 | 0 / 0 | 0 / 0 / 0 |
| `min_tt_025C_1v80` | 21.270442 | 0.268818 | 0 / 0 | 0 / 0 / 0 |
| `min_ff_n40C_1v95` | 24.125165 | 0.127634 | 0 / 0 | 0 / 0 / 0 |
| `nom_ss_100C_1v60` | 9.022511 | 0.688969 | 0 / 0 | 0 / 0 / 0 |
| `nom_tt_025C_1v80` | 20.967122 | 0.262976 | 0 / 0 | 0 / 0 / 0 |
| `nom_ff_n40C_1v95` | 23.919111 | 0.122445 | 0 / 0 | 0 / 0 / 0 |
| `max_ss_100C_1v60` | 7.542642 | 0.676393 | 0 / 0 | 0 / 0 / 0 |
| `max_tt_025C_1v80` | 20.691172 | 0.254652 | 0 / 0 | 0 / 0 / 0 |
| `max_ff_n40C_1v95` | 23.733656 | 0.116533 | 0 / 0 | 0 / 0 / 0 |

Mọi corner có setup TNS = 0 và hold TNS = 0. Raw unannotated-net count là 351/corner nhưng filtered count là 0/corner. Hai endpoint `ext_addr[0:1]` chỉ được chấp nhận unconstrained sau exact tied-low OpenDB proof; không có check_setup warning khác được chấp nhận.

## 5. Physical signoff/checker

| Checker | Kết quả cuối |
|---|---:|
| TritonRoute DRC | 0 |
| Disconnected pins | 0 |
| Antenna nets / pins | 0 / 0 |
| XOR differences | 0 |
| Magic DRC | 0 |
| KLayout DRC | 0 |
| Illegal overlap | 0 |
| LVS errors | 0 |
| LVS unmatched pins / nets | 0 / 0 |
| Power-grid violations | 0 |

## 6. IR drop

IR được chạy tại corner `max_ss_100C_1v60`, nguồn 1.60 V. Tool báo mọi shape trên VPWR/VGND đều connected.

| Net | Average drop/rise | Worst drop/rise | Tỷ lệ | Điện áp xấu nhất |
|---|---:|---:|---:|---:|
| VPWR | 4.78e-05 V = 0.0478 mV | 3.40e-04 V = 0.340 mV | 0.02% | 1.59966 V |
| VGND | 4.81e-05 V = 0.0481 mV | 3.50e-04 V = 0.350 mV | 0.02% | 0.000349822 V |

Giới hạn IR: power/activity là vectorless/tool-default; không có `VSRC_LOC_FILES` vị trí nguồn/package thực; dự án chưa đặt ngưỡng silicon acceptance cho IR. Vì vậy đây là ước lượng PDN của layout trong môi trường công cụ, không phải bảo đảm IR của chip đóng gói.

## 7. Functional verification đã xác nhận

- DMA-v2 standalone: `DMA_V2_UNIT_FUNCTIONAL_PASS`, 181 cases, host simulation wall 6.177 s. Đây là unit test, không có CPU/ASIC.
- M3 SoC matrix: 17 RUN PASS; CPU RTL thật, cùng CPU/arbiter/TB RAM; pixel và traffic checks đều PASS.
- Điều kiện biên đã bao phủ: grayscale và RGB; `1×1`, `1×7`, `9×1`; kích thước lẻ `17×19`, `37×35`; tile `16/32/64`; memory wait `0/1/3`; grayscale tới `480×320`.

### M3 SoC — bảng số liệu chính

| RUN | Ảnh | Ch | Tile/W | Samples | S1 cycles | H1 cycles | H2 cycles | S1/H2 | H1/H2 | H2 @25MHz |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| `s2_m3_soc_gray37x35_w1_01` | 37×35 | 1 | 16/1 | 1295 | 421749 | 90106 | 27688 | 15.232× | 3.254× | 0.001108 s |
| `s2_m3_soc_gray64_t64_w1_01` | 64×64 | 1 | 64/1 | 4096 | 1221362 | 278200 | 68287 | 17.886× | 4.074× | 0.002731 s |
| `s2_m3_soc_gray9x1_w1_01` | 9×1 | 1 | 16/1 | 9 | 3834 | 1134 | 1076 | 3.563× | 1.054× | 0.000043 s |
| `s2_m3_soc_h2char_g128x128_t32_w1_01` | 128×128 | 1 | 32/1 | 16384 | 5002475 | 1125450 | 286501 | 17.461× | 3.928× | 0.011460 s |
| `s2_m3_soc_h2char_g256x256_t32_w1_01` | 256×256 | 1 | 32/1 | 65536 | 20039142 | 4521530 | 1150057 | 17.424× | 3.932× | 0.046002 s |
| `s2_m3_soc_h2char_g320x240_t32_w1_01` | 320×240 | 1 | 32/1 | 76800 | 23490947 | 5302041 | 1352571 | 17.368× | 3.920× | 0.054103 s |
| `s2_m3_soc_h2char_g32x32_t32_w1_01` | 32×32 | 1 | 32/1 | 1024 | 310052 | 68987 | 18044 | 17.183× | 3.823× | 0.000722 s |
| `s2_m3_soc_h2char_g480x320_t32_w1_01` | 480×320 | 1 | 32/1 | 153600 | 46994735 | 10613703 | 2699463 | 17.409× | 3.932× | 0.107979 s |
| `s2_m3_soc_h2char_g64x64_t16_w1_01` | 64×64 | 1 | 16/1 | 4096 | 1296502 | 283270 | 80071 | 16.192× | 3.538× | 0.003203 s |
| `s2_m3_soc_h2char_g64x64_t32_w0_01` | 64×64 | 1 | 32/0 | 4096 | 1034261 | 210844 | 58484 | 17.685× | 3.605× | 0.002339 s |
| `s2_m3_soc_h2char_g64x64_t32_w1_01` | 64×64 | 1 | 32/1 | 4096 | 1247066 | 279162 | 71435 | 17.457× | 3.908× | 0.002857 s |
| `s2_m3_soc_h2char_g64x64_t32_w3_01` | 64×64 | 1 | 32/3 | 4096 | 1672676 | 436109 | 104596 | 15.992× | 4.169× | 0.004184 s |
| `s2_m3_soc_h2char_g64x64_t64_w1_01` | 64×64 | 1 | 64/1 | 4096 | 1224030 | 278200 | 68287 | 17.925× | 4.074× | 0.002731 s |
| `s2_m3_soc_rgb17x19_w3_01` | 17×19 | 3 | 16/3 | 969 | 430613 | 101421 | 30762 | 13.998× | 3.297× | 0.001230 s |
| `s2_m3_soc_rgb1x1_w0_01` | 1×1 | 3 | 1/0 | 3 | 2414 | 864 | 999 | 2.416× | 0.865× | 0.000040 s |
| `s2_m3_soc_rgb1x7_w3_01` | 1×7 | 3 | 2/3 | 21 | 21378 | 5116 | 5347 | 3.998× | 0.957× | 0.000214 s |
| `s2_m3_soc_rgb32_w1_01` | 32×32 | 3 | 16/1 | 3072 | 959301 | 206960 | 57515 | 16.679× | 3.598× | 0.002301 s |

`@25MHz` là thời gian suy ra từ cycle count × 40 ns, không phải wall-clock simulator hay phép đo board. Mỗi interval M3 gồm transfer/control/tile overhead, loại boot và host decoding. Host simulator wall time nằm đầy đủ trong CSV/JSON đi kèm.

### H3 workload chính xác hơn với physical top

| Ảnh | Tile/W | Operator | CPU-frame cycles | Busy cycles | Reads/Writes | Checked bytes | @25MHz |
|---|---:|---|---:|---:|---:|---:|---:|
| 17×19 | 16/1 | sobel | 6830 | 6108 | 399/323 | 662 | 0.000273 s |
| 17×19 | 16/1 | box | 6270 | 5519 | 399/323 | 662 | 0.000251 s |
| 65×67 | 32/3 | sobel | 100210 | 98402 | 4899/4355 | 8726 | 0.004008 s |
| 65×67 | 32/3 | box | 95254 | 93419 | 4899/4355 | 8726 | 0.003810 s |
| 128×96 | 64/1 | sobel | 204268 | 203557 | 12740/12288 | 24592 | 0.008171 s |
| 128×96 | 64/1 | box | 178810 | 178098 | 12740/12288 | 24592 | 0.007152 s |
| 480×320 | 64/1 | sobel | 2559801 | 2554850 | 162032/153600 | 307216 | 0.102392 s |
| 480×320 | 64/1 | box | 2240571 | 2235411 | 162032/153600 | 307216 | 0.089623 s |

Host-fed natural-image test `480×320` qua word port cũng PASS: 2 frames, 307200 output pixels, 1200 tile jobs, interval first-RX→last-TX 32111977 cycles = 1.284479 s tại 25 MHz; interval này gồm CPU loading/output và host stalls, loại boot. Hai ảnh Sobel/Box được tái tạo từ actual audited TX stream và có SHA256 trong JSON.

### Nhóm robustness/integration H3 đã PASS

- `H3_P1B_WRITEBACK_AUDIT_PASS` — `s2_h3_writeback_01`. Writer/adapter unit integration only. No CPU/MMIO/abort/full dataflow or H2 overhead. ASIC/FPGA NOT_RUN.
- `H3_P1C_DATAPATH_AUDIT_PASS` — `s2_h3_datapath_01`. Memory-to-memory dataflow harness, validated-descriptor precondition. CPU/MMIO/descriptor validation/job abort/H2 comparable overhead NOT_VERIFIED. ASIC/FPGA NOT_RUN.
- `H3_P1D_CONTROL_AUDIT_PASS` — `s2_h3_control_01`. MMIO master testbench plus controlled datapath. Native backend has no error pin. CPU firmware, full abort-phase matrix, large images and H2 comparable overhead NOT_VERIFIED. ASIC/FPGA NOT_RUN.
- `H3_P1E_SOC_AUDIT_PASS` — `s2_h3_soc_01`. Real PicoRV32 firmware; external memory and host logger are testbench models. Small-frame functional/counter gate only. Full abort/reset matrix, large/natural images, H2 comparable overhead and physical/FPGA NOT_VERIFIED.
- `H3_P1F_REAUDIT_PASS` — `s2_h3_lifecycle_01`. Targeted MMIO-master lifecycle verification. Not exhaustive/formal coverage; memory backend implementation, native error injection, H3 PPA and FPGA not verified.
- `H3_P1G_MEMORY_AUDIT_PASS` — `s2_h3_memory_01`. CPU plus inferred RAM/controller; code loaded through boot port by testbench, host logger remains external. RAM mapping/timing/ASIC/FPGA not verified. Small-frame scope, not H2 comparable timing.
- `H3_P1H_MEMCONTRACT_AUDIT_PASS` — `s2_h3_memcontract_01`. Banked descriptor profile + RAM unit checks + CPU fault readback. Inferred RAM mapping/ASIC/FPGA not verified. Boot transport and host logger remain TB. No native error propagation to H3; sticky fault is CPU-polled.
- `H3_GRANTFAST_AUDIT_PASS` — `s2_h3_grantfast_01`. Candidate regression and synthetic small-frame timing only; not exhaustive lifecycle coverage, inferred RAM integration, ASIC or FPGA acceptance.
- `H3_GRANTMEM_AUDIT_PASS` — `s2_h3_grantmem_01`. Banked descriptor profile + RAM unit checks + CPU fault readback. Inferred RAM mapping/ASIC/FPGA not verified. Boot transport and host logger remain TB. No native error propagation to H3; sticky fault is CPU-polled.
- `H3_WORKLOAD_AUDIT_PASS` — `s2_h3_workload_01`. Chi tiết phép đo và giới hạn nằm trong audit JSON của archive.
- `H3_NATURAL_AUDIT_PASS` — `s2_h3_natural_01`. Chi tiết phép đo và giới hạn nằm trong audit JSON của archive.
- `H3_TILEFEED_AUDIT_PASS` — `s2_h3_tilefeed_02`. CPU host-fed tile pilot via RTL word endpoint, finite inferred RAM. Host peer/boot remain TB. UART/large-frame tilefeed/ASIC/FPGA not verified.
- `H3_TILEFAULT_AUDIT_PASS` — `s2_h3_tilefault_01`. Invalid/truncated input and shared-reset recovery pilot. No autonomous timeout or active-DMA transport reset coverage. Peer/boot TB; UART/FPGA NOT_RUN.
- `H3_TILELARGE_AUDIT_PASS` — `s2_h3_tilelarge_01`. Natural480x320 via CPU/word port and finite inferred RAM; host frame and boot transport TB. UART/RAM mapping/ASIC/FPGA not verified.
- `H3_WORDTOP_AUDIT_PASS` — `s2_h3_wordtop_01`. Integrated CPU/H3 grantfast/RAM/word endpoint top; small-frame regression. Boot and peer remain TB. Active-transfer reset, UART, RAM mapping, ASIC/FPGA NOT_VERIFIED.
- `H3_WORDRESET_AUDIT_PASS` — `s2_h3_wordreset_01`. Three shared-reset cases: pending read, pending write after partial output, stalled host TX; full fresh-session recovery. Boot/peer TB. UART/CDC, exhaustive reset, RAM mapping, ASIC/FPGA NOT_VERIFIED.
- `H3_UARTBOOT_AUDIT_PASS` — `s2_h3_uartboot_01`. Firmware boot and image I/O through UART pins, nominal DIV8 simulation. Host remains TB. Runtime CRC/retry/timeout, serial reset, BRAM/timing/ASIC/FPGA NOT_VERIFIED.
- `H3_UARTGUARD_AUDIT_PASS` — `s2_h3_uartguard_01`. Boot header rejection, shared reset mid RX/partial boot, RX bit periods +/-2% at DIV8. Runtime reset/CRC/retry/timeout, BRAM/timing/ASIC/FPGA NOT_VERIFIED.
- `H3_UARTRUNTIME_AUDIT_PASS` — `s2_h3_uartruntime_01`. Shared reset during pending DMA write or UART data bits; full serial reboot/recovery. Host-only reset, runtime CRC/retry/timeout, BRAM/timing/ASIC/FPGA NOT_VERIFIED.
- `H3_HOSTCOSIM_AUDIT_PASS` — `s2_h3_hostcosim_01`. Actual Python session to UART RTL via TB-only byte bridge at DIV8. Not OS serial driver, board, BRAM, timing or ASIC PPA. Host scheduling affects simulated wait cycles.

## 8. Cách hiểu RUN 79 stage

Stages 1-43 run from frozen RTL/config. Stage 44 hash-gates design identity and rejoins the exact RUN300 converged topology, placement and routed checkpoint with replaceable fill removed. Downstream DRT, antenna, fill, RCX, timing/electrical and final signoff checks execute in this run. Routing is guided/reused, not regenerated from scratch.

Đây là full Classic run có hướng dẫn/checkpoint rejoin được công khai, không phải fresh routing hoàn toàn từ số 0. Stages 1–43 chạy từ frozen RTL/config; stage rejoin kiểm hash/structural identity rồi đưa topology-placement-route đã hội tụ vào cùng flow; detailed routing, antenna closure, fill, RCX, nine-corner STA, IR, GDS, XOR, Magic/KLayout DRC, LVS và manufacturability đều chạy tiếp trong RUN này.

Các cảnh báo được giữ trong evidence gồm: GRT-0097/GRT-0026 ở các stage trung gian trước rejoin; DRT LEF58 CUTCLASS chưa được hỗ trợ; wirelength threshold không đặt nên checker đó skip; IR thiếu source-location thực; hai output pin thiếu antenna diffusion metadata; EQY bị disable. Các cảnh báo này không được dùng để thay thế checker cuối; checker cuối ở bảng trên vẫn phải bằng 0.

## 9. Giới hạn bắt buộc ghi trong báo cáo Word

1. Đây là kết quả OpenLane/SKY130 phục vụ nghiên cứu/phòng thí nghiệm, không phải industrial tape-out approval.
2. PPA thuộc CPU + H3 logic top; không gồm external RAM, UART, camera, pad ring hay package.
3. Power là vectorless; không được gọi là năng lượng xử lý ảnh thực tế.
4. IR thiếu vị trí nguồn/package thực và chưa có ngưỡng acceptance riêng.
5. Functional simulation, FPGA board test và ASIC physical signoff là ba loại bằng chứng khác nhau; không trộn thời gian PC, thời gian mô phỏng mục tiêu và thời gian board.
6. PASS chính thức phải ghi đầy đủ là `C40_MONOLITHIC_79_CLASSIC_PASS_WITH_DOCUMENTED_GUIDANCE`.

## 10. Evidence gốc

- Physical: `E:\aa. PPA_Project_List\aaa.PicoRV32_Sobel_ASIC_PPA\upgrade\reports\s2_h3_c40_monolithic_06_evidence.zip`
- SHA256 physical: `f2e782836919896c9a740b6d05a8f27f82beb15b91d9a0f716c2f983b9e9633d`
- Flow wall time do wrapper ghi: 2333.977 s (38.90 phút); đây là thời gian chạy trên PC.
- Danh sách archive và SHA256 functional/component nằm trong `C40_CONSOLIDATED_DATA.json` và hai CSV.

## 11. File đi kèm

- `C40_CONSOLIDATED_DATA.json`: dữ liệu máy đọc đầy đủ.
- `C40_STA_9_CORNERS.csv`: STA/electrical chín corner.
- `C40_FUNCTIONAL_TEST_MATRIX.csv`: toàn bộ M3 SoC functional runs.
- `C40_H3_WORKLOAD_MATRIX.csv`: workload H3 Sobel/Box.
- `SHA256SUMS.txt`: hash của bộ báo cáo xuất ra.
